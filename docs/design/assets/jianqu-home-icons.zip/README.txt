见趣 HOME 图标素材 / Jianqu HOME icons
30 icons; 256×256 transparent PNG + lossless WebP.
Based on regenerated transparent asset sheet, visually referencing approved HOME concept; not exact original screenshot pixels. Small original glyphs are upscaled, not vector assets. Brand butterfly is a concept, not confirmed official logo.

video: source crop 225×208
health: source crop 221×185
lecture: source crop 220×181
shopping: source crop 194×207
contacts: source crop 218×186
alarm: source crop 221×203
album: source crop 211×178
activity: source crop 209×181
settings: source crop 180×179
all-apps: source crop 164×159
voice: source crop 159×128
wifi: source crop 169×133
partly-cloudy: source crop 187×172
sunny: source crop 172×173
cloudy: source crop 172×116
rain: source crop 161×160
brand-butterfly: source crop 150×99
support: source crop 102×102
debug: source crop 104×93
chevron-right: source crop 32×51
chevron-left: source crop 28×52
close: source crop 83×82
check-circle: source crop 78×78
radio-off: source crop 65×67
radio-on: source crop 68×69
checkbox-on: source crop 68×67
checkbox-off: source crop 66×67
thunder: source crop 114×119
snow: source crop 111×114
fog: source crop 109×113